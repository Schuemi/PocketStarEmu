

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
using namespace std;
//to install:
//wget https://github.com/Schuemi/PocketStarEmu/blob/master/test/flasher.tar.gz?raw=true -O flasher.tar.gz


//to compile on rasp: gcc main.cpp -o flasher
/*
 * 
 */
int flashDevice(const char* port) {
    char buf[512];
    char output[1035];
    FILE *fp;
    snprintf(buf, 512, "esptool.py -p /dev/%s -b 460800 --before default_reset --after hard_reset --chip esp32c3 --no-stub write_flash --flash_mode dio --flash_size detect --flash_freq 80m 0x0 Firmware/bootloader.bin 0x8000 Firmware/partition-table.bin 0xe000 Firmware/ota_data_initial.bin 0x10000 Firmware/loadapp.bin 0x90000 Firmware/FactoryTest.bin 0x9000 Firmware/nvs.bin", port);
    //int res = system(buf);
    fp = popen(buf, "r");
    if (fp == NULL) return -1;
    while (fgets(output, sizeof(output), fp) != NULL) {
        if (strstr(output, "MAC:")) {
            printf("Found %s", output);
        }
        
    } 

    /* close */
    pclose(fp);
    
    //printf("Flash result: %d\n", res);
    return 0;
}
int main(int argc, char** argv) {
    char line[1024];
    printf("Pocuter Flasher 0.1\n");
    FILE* kmsg = fopen("/dev/kmsg", "r");
    if (kmsg) {
        fseek(kmsg, 0, SEEK_END); 
        while( fgets(line,1024,kmsg) ) {
            
            if (strstr(line , "USB ACM device")) {
                char* w = strstr(line , "ttyACM");
                if (w) {
                    char* wend = strstr(w , ":");
                    if (wend) {
                        wend[0] = 0;
                        printf("Got ACM Device: %s\n", w);
                        if (fork() == 0) {
                            flashDevice(w);
                            return 0;
                        }
                        
                    }
                    
                }
                
            }
        }
    }
    
    
    return 0;
}

