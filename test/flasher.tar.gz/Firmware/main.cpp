

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/file.h>
using namespace std;
//to install:
//wget https://github.com/Schuemi/PocketStarEmu/blob/master/test/flasher.tar.gz?raw=true -O flasher.tar.gz


//to compile on rasp: gcc main.cpp -o flasher
/*
 * 
 */
int flashDevice(const char* port, const char* usbPort) {
    char buf[512];
    char output[1035];
    FILE *fp;
    snprintf(buf, 512, "esptool.py -p /dev/%s -b 460800 --before default_reset --after hard_reset --chip esp32c3 --no-stub write_flash --flash_mode dio --flash_size detect --flash_freq 80m 0x0 Firmware/bootloader.bin 0x8000 Firmware/partition-table.bin 0xe000 Firmware/ota_data_initial.bin 0x10000 Firmware/loadapp.bin 0x90000 Firmware/FactoryTest.bin 0x9000 Firmware/nvs.bin", port);
    //int res = system(buf);
    fp = popen(buf, "r");
    if (fp == NULL) return -1;
    char buf2[20];
    bool foundMac = false;
    
    while (fgets(output, sizeof(output), fp) != NULL) {
        if (strstr(output, "MAC:")) {
            char* mac = output + 5;
            memcpy(buf2, mac, 17);
            buf2[17] = 0;
            foundMac = true;
            printf("Found %s\n", buf2);
        }
        
    }
    
    /* close */
    pclose(fp);
    if (foundMac) {
        
        // delete the ':'
        char *p = buf2;
        char *dest = buf2;
        int pos = 0;
        while (*p != 0) {
            if (*p == ':') p++;
            dest[pos++] = *p;
            p++;
        }
        dest[pos++] = 0;
        printf("ID: %s\n", dest);
            
        
        char fileName[256];
        snprintf(fileName, 256, "./IDs_%s.TXT", usbPort);
        FILE* f = fopen(fileName, "a");
        if (f) {
            flock(fileno(f), LOCK_EX);
            fputs(buf2, f);
            fputs(";", f);
            flock(fileno(f), LOCK_UN);
            fclose(f);
        } else {
            printf("Could not generate File!\n");
        }
    }

    
    //printf("Flash result: %d\n", res);
    return 0;
}
int main(int argc, char** argv) {
    char line[1024];
    printf("Pocuter Flasher 0.1\n");
    FILE* kmsg = fopen("/dev/kmsg", "r");
    if (kmsg) {
        fseek(kmsg, 0, SEEK_END); 
        while( fgets(line,1024,kmsg) ) {
            
            if (strstr(line , "USB ACM device")) {
                char* d = strstr(line , "cdc_acm");
                char* w = strstr(line , "ttyACM");
                if (w) {
                    char* wend = strstr(w , ":");
                    
                    if (wend) {
                        wend[0] = 0;
                        char* dend = NULL;
                        if (d) {d += 8; dend = strstr(d , ":");}
                        if (dend) dend[0] = 0; else d = NULL;
                        printf("Got ACM Device: %s USB: %s\n", w,d);
                        if (fork() == 0) {
                            flashDevice(w,d);
                            return 0;
                        }
                        
                    }
                    
                }
                
            }
        }
    }
    
    
    return 0;
}

