#!/bin/bash
sudo apt-get --yes update   
sudo apt-get --yes upgrade
sudo apt-get --yes install python3-pip 
sudo pip install esptool 
gcc main.cpp -o flasher
sudo mkdir /opt/flash
sudo cp flasher /opt/flash
sudo mkdir /opt/flash/Firmware
sudo cp *.bin /opt/flash/Firmware
sudo cp autostart/flasherScript /etc/init.d/
sudo chmod 755 /etc/init.d/flasherScript
sudo update-rc.d flasherScript defaults

