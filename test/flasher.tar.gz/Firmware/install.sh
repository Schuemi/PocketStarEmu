#!/bin/bash
sudo apt-get update   
sudo apt-get upgrade
sudo apt-get install python3-pip 
sudo pip install esptool 
gcc main.cpp -o flasher
sudo cp autostart/flasherScript /etc/init.d/
sudo chmod 755 /etc/init.d/flasherScript
sudo update-rc.d flasherScript defaults

